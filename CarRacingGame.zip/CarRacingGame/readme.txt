javac *.java
java CarRacingGame
