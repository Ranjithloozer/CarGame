import java.awt.*;
import javax.swing.*;
import java.awt.event.KeyEvent;


public class Car {
    private int x, y;
    private final int width = 50, height = 100;
    private Image carImage;

    public Car(int x, int y, String imagePath) {
        this.x = x;
        this.y = y;
        this.carImage = new ImageIcon(imagePath).getImage();
    }

    public void draw(Graphics g) {
        g.drawImage(carImage, x, y, width, height, null);
    }

    public void handleKey(KeyEvent e, int panelWidth) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT && x > 0) {
            x -= 20;
        }
        if (e.getKeyCode() == KeyEvent.VK_RIGHT && x < panelWidth - width) {
            x += 20;
        }
    }

    // ✅ Fix: Add autoMove for AI
    public void autoMove(Rectangle obstacle, int panelWidth) {
        if (obstacle == null) return;
        if (obstacle.x + 25 < x + width / 2 && x > 0) {
            x -= 10;
        } else if (obstacle.x + 25 > x + width / 2 && x < panelWidth - width) {
            x += 10;
        }
    }

    public void reset() {
        x = 200;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }
}
