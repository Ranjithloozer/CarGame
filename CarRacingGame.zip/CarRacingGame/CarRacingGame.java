// File: CarRacingGame.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CarRacingGame extends JPanel implements ActionListener, KeyListener {
    private Car car;
    private ObstacleManager obstacleManager;
    private GameStateManager gameStateManager;
    private Countdown countdown;

    private Image bgDay, bgNight;
    private Image[] carChoices;
    private Timer gameTimer;

    private boolean paused = false;
    private boolean carSelected = false;
    private boolean isDay = true;
    private boolean showMenu = true;
    private boolean aiMode = false;
    private boolean powerUpActive = false;

    private int powerUpTimer = 0;

    public CarRacingGame() {
        setFocusable(true);
        addKeyListener(this);

        carChoices = new Image[] {
            new ImageIcon("assets/car1.png").getImage(),
            new ImageIcon("assets/car2.png").getImage(),
            new ImageIcon("assets/car3.png").getImage()
        };

        bgDay = new ImageIcon("assets/background_day.jpg").getImage();
        bgNight = new ImageIcon("assets/background_night.jpg").getImage();

        obstacleManager = new ObstacleManager("assets/obstacle.png");
        gameStateManager = new GameStateManager("highscore.txt");

        SoundPlayer.loopSound("assets/bgm.wav");
    }

    private void startCountdown() {
        countdown = new Countdown(() -> startGame());
    }

    private void startGame() {
        gameTimer = new Timer(30, this);
        gameTimer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(isDay ? bgDay : bgNight, 0, 0, getWidth(), getHeight(), this);

        if (showMenu) {
            drawMainMenu(g);
            return;
        }

        if (!carSelected) {
            drawCarSelection(g);
            return;
        }

        obstacleManager.drawRoadLines(g, getHeight());
        if (car != null) car.draw(g);
        obstacleManager.drawObstacles(g);
        gameStateManager.drawScore(g);

        if (gameStateManager.isGameOver()) {
            gameStateManager.drawGameOver(g);
        } else if (countdown != null && countdown.isCounting()) {
            countdown.draw(g, getWidth(), getHeight());
        } else if (paused) {
            g.setColor(Color.ORANGE);
            g.setFont(new Font("Arial", Font.BOLD, 36));
            g.drawString("PAUSED", 120, 320);
        } else if (aiMode) {
            g.setColor(Color.GREEN);
            g.setFont(new Font("Arial", Font.BOLD, 18));
            g.drawString("AI MODE ON", 260, 30);
        }

        if (powerUpActive) {
            g.setColor(Color.MAGENTA);
            g.setFont(new Font("Arial", Font.BOLD, 18));
            g.drawString("NITRO BOOST!", 140, 60);
        }
    }

    private void drawCarSelection(Graphics g) {
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 28));
        g.drawString("Select Your Car (1-3):", 60, 80);

        for (int i = 0; i < carChoices.length; i++) {
            g.drawImage(carChoices[i], 50 + i * 110, 150, 80, 120, this);
            g.drawString("" + (i + 1), 85 + i * 110, 290);
        }
    }

    private void drawMainMenu(Graphics g) {
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 36));
        g.drawString("Car Racing Game", 70, 150);

        g.setFont(new Font("Arial", Font.PLAIN, 24));
        g.drawString("Press ENTER to Start", 100, 250);
        g.drawString("H - Help | Q - Quit", 110, 290);
    }

    public void actionPerformed(ActionEvent e) {
        if (!paused && !gameStateManager.isGameOver()) {
            if (aiMode && car != null) {
                car.autoMove(obstacleManager.getClosestObstacle(car.getBounds()), getWidth());
            }

            if (powerUpActive) {
                powerUpTimer--;
                if (powerUpTimer <= 0) powerUpActive = false;
            }

            obstacleManager.updateObstacles(car.getBounds(), gameStateManager, powerUpActive);
            repaint();
        }
    }

    public void keyPressed(KeyEvent e) {
        if (showMenu) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                showMenu = false;
                repaint();
            } else if (e.getKeyCode() == KeyEvent.VK_Q) {
                System.exit(0);
            } else if (e.getKeyCode() == KeyEvent.VK_H) {
                JOptionPane.showMessageDialog(this, "Controls:\n←/→: Move\nP: Pause\nD: Toggle Day/Night\nA: Toggle AI Mode\nN: Nitro Boost\nR: Restart\n1-3: Select Car");
            }
            return;
        }

        if (!carSelected) {
            if (e.getKeyCode() == KeyEvent.VK_1 || e.getKeyCode() == KeyEvent.VK_NUMPAD1) {
                car = new Car(200, 500, "assets/car1.png");
            } else if (e.getKeyCode() == KeyEvent.VK_2 || e.getKeyCode() == KeyEvent.VK_NUMPAD2) {
                car = new Car(200, 500, "assets/car2.png");
            } else if (e.getKeyCode() == KeyEvent.VK_3 || e.getKeyCode() == KeyEvent.VK_NUMPAD3) {
                car = new Car(200, 500, "assets/car3.png");
            }

            if (car != null) {
                carSelected = true;
                startCountdown();
                repaint();
            }
            return;
        }

        if (!gameStateManager.isGameOver() && !countdown.isCounting()) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_P:
                    paused = !paused;
                    if (paused) gameTimer.stop();
                    else gameTimer.start();
                    break;
                case KeyEvent.VK_D:
                    isDay = !isDay;
                    break;
                case KeyEvent.VK_A:
                    aiMode = !aiMode;
                    break;
                case KeyEvent.VK_N:
                    powerUpActive = true;
                    powerUpTimer = 100; // lasts ~3 seconds
                    break;
                default:
                    if (!aiMode) car.handleKey(e, getWidth());
            }
            repaint();
        } else if (e.getKeyCode() == KeyEvent.VK_R) {
            restartGame();
        }
    }

    private void restartGame() {
        car.reset();
        obstacleManager.reset();
        gameStateManager.reset();
        paused = false;
        aiMode = false;
        powerUpActive = false;
        countdown.restart();
        repaint();
    }

    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("\uD83C\uDFCE\uFE0F Car Racing Game");
        CarRacingGame game = new CarRacingGame();
        frame.add(game);
        frame.setSize(400, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}