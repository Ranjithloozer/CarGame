import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class ObstacleManager {
    private int[][] obstacles = new int[3][2];
    private Image obstacleImage;
    private int roadLineY = 0;
    private int speed = 10;

    public ObstacleManager(String imagePath) {
        obstacleImage = new ImageIcon(imagePath).getImage();
        reset();
    }

    public void reset() {
        Random rand = new Random();
        for (int i = 0; i < obstacles.length; i++) {
            obstacles[i][0] = rand.nextInt(350);  // X position
            obstacles[i][1] = -i * 300;           // Y position
        }
        speed = 10;
        roadLineY = 0;
    }

    public void updateObstacles(Rectangle carRect, GameStateManager gsm, boolean powerUpActive) {
        roadLineY += speed;

        for (int i = 0; i < obstacles.length; i++) {
            // Move obstacles
            obstacles[i][1] += powerUpActive ? speed * 2 : speed;

            // Respawn when out of screen
            if (obstacles[i][1] > 700) {
                obstacles[i][1] = -200;
                obstacles[i][0] = new Random().nextInt(350);
                gsm.increaseScore();
                if (gsm.getScore() % 5 == 0) speed++;
            }

            // Collision detection
            Rectangle obsRect = new Rectangle(obstacles[i][0], obstacles[i][1], 50, 100);
            if (carRect.intersects(obsRect)) {
                SoundPlayer.playSound("assets/crash.wav");
                gsm.setGameOver(true);
                gsm.saveHighScore(); // Ensure this method is public in GameStateManager
            }
        }
    }

    public void drawObstacles(Graphics g) {
        for (int[] obs : obstacles) {
            g.drawImage(obstacleImage, obs[0], obs[1], 50, 100, null);
        }
    }

    public void drawRoadLines(Graphics g, int panelHeight) {
        g.setColor(Color.WHITE);
        for (int i = 0; i < 10; i++) {
            g.fillRect(180, (roadLineY + i * 80) % panelHeight, 10, 40);
            g.fillRect(310, (roadLineY + i * 80) % panelHeight, 10, 40);
        }
    }

    public Rectangle getClosestObstacle(Rectangle carRect) {
        Rectangle closest = null;
        int minDist = Integer.MAX_VALUE;

        for (int[] obs : obstacles) {
            Rectangle obsRect = new Rectangle(obs[0], obs[1], 50, 100);
            int dist = obs[1] - carRect.y;
            if (dist > 0 && dist < minDist) {
                minDist = dist;
                closest = obsRect;
            }
        }

        return closest;
    }
}