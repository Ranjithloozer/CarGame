import java.awt.*;
import java.util.*;

public class Countdown {
    private int countdown = 3;
    private java.util.Timer timer;
    private boolean counting = true;
    private Runnable onFinish;

    public Countdown(Runnable onFinish) {
        this.onFinish = onFinish;
        start();
    }

    public void start() {
        timer = new java.util.Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if (countdown > 0) {
                    countdown--;
                } else {
                    counting = false;
                    timer.cancel();
                    onFinish.run();
                }
            }
        }, 0, 1000);
    }

    public void draw(Graphics g, int width, int height) {
        g.setColor(Color.CYAN);
        g.setFont(new Font("Arial", Font.BOLD, 60));
        if (countdown > 0)
            g.drawString(String.valueOf(countdown), width / 2 - 20, height / 2);
        else
            g.drawString("GO!", width / 2 - 40, height / 2);
    }

    public boolean isCounting() {
        return counting;
    }

    public void restart() {
        countdown = 3;
        counting = true;
        start();
    }
}
