import java.awt.*;
import java.io.*;
import java.util.*;

public class GameStateManager {
    private int score = 0;
    private int highScore = 0;
    private boolean gameOver = false;
    private String filePath;

    public GameStateManager(String filePath) {
        this.filePath = filePath;
        loadHighScore();
    }

    // ✅ Fix: Public method for increasing score
    public void increaseScore() {
        score++;
    }

    public int getScore() {
        return score;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean value) {
        gameOver = value;
    }

    public void reset() {
        score = 0;
        gameOver = false;
    }

    public void drawScore(Graphics g) {
        g.setColor(Color.YELLOW);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Score: " + score, 20, 30);
        g.drawString("High Score: " + highScore, 20, 55);
    }

    public void drawGameOver(Graphics g) {
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 36));
        g.drawString("GAME OVER", 100, 300);

        g.setFont(new Font("Arial", Font.PLAIN, 20));
        g.drawString("Press R to Restart", 120, 350);
    }

    private void loadHighScore() {
        try {
            File f = new File(filePath);
            if (f.exists()) {
                Scanner sc = new Scanner(f);
                if (sc.hasNextInt()) highScore = sc.nextInt();
                sc.close();
            }
        } catch (Exception e) {
            System.out.println("Error reading highscore");
        }
    }

    // ✅ Fix: Make this public!
    public void saveHighScore() {
        try {
            if (score > highScore) {
                FileWriter fw = new FileWriter(filePath);
                fw.write(String.valueOf(score));
                fw.close();
            }
        } catch (Exception e) {
            System.out.println("Error saving highscore");
        }
    }
}
